//index do filme
export default function Filmes(){
    return(
        <div>
            <h1>Bem Vindo a Filmes</h1>
        </div>
    )



}